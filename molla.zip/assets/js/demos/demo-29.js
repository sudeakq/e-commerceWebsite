//Demo 29 Js file
(function($) {
    'use strict';
    
    // var owl = $('.owl-carousel');

    // owl.on('initialized.owl.carousell', function(event) {
    //     console.log("OwL: Loaded");
    // })
})(jQuery);